import streamlit_authenticator as stauth
from streamlit_authenticator.utilities.hasher import Hasher

hashedPasswords = Hasher(['abc']).generate()
