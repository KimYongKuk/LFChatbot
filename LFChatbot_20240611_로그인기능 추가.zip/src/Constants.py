#CONST
NAME = '김용국(wg0403)' 
CHROMADB_PATH   = "./chdata" 
DOC_PATH = "./data"
CHUNK_SIZE = 400
RES_MESSAGE = 'test'
COLLECTION_NAME = 'lftest10'